#include <iostream>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <fstream>

#include "BinarySearchTree.h"
#include "AvlTree.h"

#define MAX_VAL 10000000

using namespace std;


/**
 * Class for keeping track of shared tree data.
 */
class Stats {
public:
  Stats( ) : operations{0}, nodes{0}, numOfInserts{0}, numOfDeletes{0}, numOfSearches{0}
  {  }

  int operations;
  int nodes;
  int numOfInserts;
  int numOfDeletes;
  int numOfSearches;
};


/**
 * Class for keeping track of BST and AVL data.
 */
class TreeStats {
public:
  TreeStats( ) : totalInsertT{0}, totalDeleteT{0}, totalSearchT{0}
  {  }

  double totalInsertT;
  double totalDeleteT;
  double totalSearchT;
};


/**
 * Returns elapsed time in milliseconds.
 */
double elapsedTime(clock_t start, clock_t finish) {
  return (finish - start)/(double)(CLOCKS_PER_SEC/1000);
}


/**
 * Returns the maximum of three numbers.
 */
int max3(int a, int b, int c) {
  int max;

  if(a > b && a > c)
    max = a;
  else if(b > c)
    max = b;
  else
    max = c;

  return max;
}


/**
 * Insert keys < MAX_VAL randomly into both trees.
 * Allow attempting to insert duplicates.
 * Does not track stats.
 * Returns true if inserted a new node, false otherwise.
 */
bool insertKey(BinarySearchTree<int> *bst, AvlTree<int> *avl) {
  bool res = false;

  int key = rand() % MAX_VAL;

  if(!avl->contains(key))
    res = true;

  bst->insert(key);
  avl->insert(key);

  return res;
}


/**
 * Insert keys < MAX_VAL randomly into both trees.
 * Allow attempting to insert duplicates.
 * Tracks Stats and TreeStats for both trees.
 */
void insertKey(BinarySearchTree<int> *bst, AvlTree<int> *avl,
              TreeStats & bstStats, TreeStats & avlStats, Stats & stats) {

  clock_t start;

  int key = rand() % MAX_VAL;

  stats.numOfInserts++;
  if(!avl->contains(key)) {
    stats.nodes++;
  }

  start = clock();
  bst->insert(key);
  bstStats.totalInsertT += elapsedTime(start, clock());

  // Running contains() before timing insert() does not have any impact on
  // how long insert() takes to complete
  // Therefore we do not need to run it for bst even though we did for avl

  start = clock();
  avl->insert(key);
  avlStats.totalInsertT += elapsedTime(start, clock());
}


/**
 * Delete keys < MAX_VAL randomly on both trees.
 * Allow attempting to delete keys not in the trees or if empty.
 * Tracks Stats and TreeStats for both trees.
 */
void deleteKey(BinarySearchTree<int> *bst, AvlTree<int> *avl,
              TreeStats & bstStats, TreeStats & avlStats, Stats & stats) {

  clock_t start;

  int key = rand() % MAX_VAL;

  stats.numOfDeletes++;
  if(avl->contains(key)) {
    stats.nodes--;
  }

  start = clock();
  bst->remove(key);
  bstStats.totalDeleteT += elapsedTime(start, clock());

  // Running contains() before timing remove() does not have any impact on
  // how long remove() takes to complete
  // Therefore we do not need to run it for bst even though we did for avl

  start = clock();
  avl->remove(key);
  avlStats.totalDeleteT += elapsedTime(start, clock());
}


/**
 * Search keys < MAX_VAL randomly on both trees.
 * Allow attempting to search keys not in the trees or if empty.
 * Tracks Stats and TreeStats for both trees.
 */
void searchKey(BinarySearchTree<int> *bst, AvlTree<int> *avl,
              TreeStats & bstStats, TreeStats & avlStats, Stats & stats) {

  clock_t start;

  int key = rand() % MAX_VAL;
  stats.numOfSearches++;

  // Running contains() before timing contains() speeds up the operation
  // by over 2x on my computer!
  // Since we are running contains() before the other timed operations,
  // let's run it here as well
  bst->contains(key);

  start = clock();
  bst->contains(key);
  bstStats.totalSearchT += elapsedTime(start, clock());

  // For the same reason above, let's run contains() for the avl tree before we time it
  avl->contains(key);

  start = clock();
  avl->contains(key);
  avlStats.totalSearchT += elapsedTime(start, clock());
}


/**
 * Initialize the csv file.
 * Clear previous contents and give labels.
 */
void csvInit( ) {
  fstream fout;
  fout.open("data.csv", ofstream::out | ofstream::trunc);

  fout << "Number of Operations, " <<
  "BST Size, BST height, BST Average Depth, BST Average Insertion Time" <<
  ", BST Average Deletion Time, BST Average Search Time, " <<
  "," <<
  "AVL Size, AVL height, AVL Average Depth, AVL Average Insertion Time" <<
  ", AVL Average Deletion Time, AVL Average Search Time\n";
}


/**
 * Obtains the size, height, average node depth,
 * and average time for an operation for both trees.
 * Writes this data to a .csv file.
 * ---------------------------------------------------------------------------------------
 *                           bst                                              avl
 * operations, size, height, avg depth, operation times,    , size, height, avg depth, operation times
 */
void updateCSV(BinarySearchTree<int> *bst, AvlTree<int> *avl,
              TreeStats & bstStats, TreeStats & avlStats, Stats stats) {


  fstream fout;
  fout.open("data.csv", ios::out | ios::app);

  fout << stats.operations << ", " <<
  stats.nodes << ", " << bst->height() << ", "<<
  (float)bst->ipl() / (float)stats.nodes << ", " <<
  bstStats.totalInsertT/stats.numOfInserts << ", " <<
  bstStats.totalDeleteT/stats.numOfDeletes << ", " <<
  bstStats.totalSearchT/stats.numOfSearches << ", " <<
  ", " <<
  stats.nodes << ", " << avl->height() << ", " <<
  (float)avl->ipl() / (float)stats.nodes << ", " <<
  avlStats.totalInsertT/stats.numOfInserts << ", " <<
  avlStats.totalDeleteT/stats.numOfDeletes << ", " <<
  avlStats.totalSearchT/stats.numOfSearches << "\n";
}


/**
 * Test driver for comparing BST to AVL.
 * Insert, remove, and search trees of varying sizes.
 * Output data to a .csv file.
 */
int main(void) {
  // Seed for the random variable and initialize the .csv file
  srand(time(0));
  csvInit();

  // These will be large so put them on heap
  BinarySearchTree<int> *bst = new BinarySearchTree<int>();
  AvlTree<int> *avl = new AvlTree<int>();

  Stats stats;

  const int NUM_OPS = 5000;
  const int MAX_NODES = 10000000;

  const int MARGIN = 1000;  // how much the quantity of operations can vary


  // Insert m+2^j nodes at a time up to 1000000 nodes
  // then record operations at each of these intervals
  for(int j = 1000; j < MAX_NODES; j = (j * 10) / 5) {

    int i, d, s;
    i = d = s = 0;

    // Reset the operation time stats each interval
    TreeStats bstStats;
    TreeStats avlStats;

    stats.numOfInserts = 0;
    stats.numOfDeletes = 0;
    stats.numOfSearches = 0;

    // Increase the trees by about STEP nodes
    int k;
    for(k = 0; k < j; ++k)
      stats.nodes += insertKey(bst, avl);

    cout << "Performing long sequence of operations on tree of size " <<
    stats.nodes << "." << endl;

    // Long sequence of operations
    // Approximately NUM_OPS many inserts, deletes, and searches
    // with a lower bound of NUM_OPS - MARGIN
    while(i < NUM_OPS && d < NUM_OPS && s < NUM_OPS) {

      int maxNodes = max3(i, d, s);

      // Check if any operation needs to "catch up" to be within the margin
      if(i >= 0 && i <= maxNodes - MARGIN) {
        insertKey(bst, avl, bstStats, avlStats, stats);
        ++i;
      }
      if(d >= 0 && d <= maxNodes - MARGIN) {
        deleteKey(bst, avl, bstStats, avlStats, stats);
        ++d;
      }
      if(s >= 0 && s <= maxNodes - MARGIN) {
        searchKey(bst, avl, bstStats, avlStats, stats);
        ++s;
      }

      // Otherwise randomly choose an insert, delete, or search
      switch(rand() % 3) {
        case 0:
          insertKey(bst, avl, bstStats, avlStats, stats);
          ++i;
          break;
        case 1:
          deleteKey(bst, avl, bstStats, avlStats, stats);
          ++d;
          break;
        case 2:
          searchKey(bst, avl, bstStats, avlStats, stats);
          ++s;
          break;
      }

      stats.operations++;
    }

    updateCSV(bst, avl, bstStats, avlStats, stats);
  }

  // No memory leaks :)
  delete bst;
  delete avl;

  cout << "Finished long sequence of operations." << endl;

  return 0;
}
